drop table if exists cpas;
drop table if exists clients;
drop table if exists assistants;
drop table if exists tax_returns;